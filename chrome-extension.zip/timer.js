/* =========================================================================
 * timer.js — [3번] 경주 타이머 (모든 탭 상단 고정)
 * -------------------------------------------------------------------------
 *   - 발주시각(HH:MM) 입력 → 카운트다운 (모든 탭 chrome.storage 공유)
 *   - 남은 시간 크게 표시 + 상태(🟢 베팅가능 / 🔴 마감)
 *   - 단계 알림(🔔 소리 + 문구):
 *       10분전 → 배당판 전송 시작하세요
 *        5분전 → 배당 추세 확인
 *        3분전 → 빠른 비교 실행
 *        1분전 → 베팅 마감 임박!
 *   - 소리는 "포커스된 탭"에서만 (여러 탭 동시 비프 방지), 문구는 모든 탭 표시
 * =======================================================================*/

(() => {
  'use strict';
  if (window.top !== window) return;                 // 최상위 프레임만
  if (document.getElementById('kbTimerBar')) return; // 중복 주입 방지

  const STAGES = [
    { min: 10, msg: '📤 배당판 전송 시작하세요' },
    { min: 5, msg: '📈 배당 추세 확인' },
    { min: 3, msg: '⚡ 빠른 비교 실행' },
    { min: 1, msg: '⏰ 베팅 마감 임박!' },
  ];

  let deadline = 0;      // ms epoch (발주 시각)
  let fired = new Set(); // 이미 알린 단계(min)
  let msgUntil = 0;      // 문구 표시 만료 시각

  // ── 바 DOM (arbitrary 사이트 CSS 간섭 피하려 인라인 스타일) ──
  const bar = document.createElement('div');
  bar.id = 'kbTimerBar';
  bar.style.cssText = [
    'all:initial', 'position:fixed', 'top:0', 'left:0', 'right:0', 'z-index:2147483647',
    'height:36px', 'display:flex', 'align-items:center', 'gap:10px', 'padding:0 12px',
    'background:#0f172a', 'color:#e2e8f0',
    "font:600 13px/1 -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif",
    'box-shadow:0 2px 10px rgba(0,0,0,.35)', 'border-bottom:1px solid #334155',
  ].join(';');
  const inputCss = 'background:#1e293b;border:1px solid #334155;color:#e2e8f0;border-radius:5px;padding:3px 6px;font:inherit;height:24px';
  bar.innerHTML =
    `<span style="font-size:15px">⏱</span>` +
    `<input id="kbTimerLabel" placeholder="경주" title="경주 이름(선택)" style="${inputCss};width:66px" />` +
    `<span style="color:#94a3b8;font-weight:400">발주</span>` +
    `<input id="kbTimerTime" type="time" title="발주 시각" style="${inputCss}" />` +
    `<span id="kbTimerCount" style="font-size:19px;font-weight:800;min-width:104px;letter-spacing:.5px;font-variant-numeric:tabular-nums">--:--</span>` +
    `<span id="kbTimerStatus" style="padding:2px 9px;border-radius:6px;font-size:12px;background:#334155">대기</span>` +
    `<span id="kbTimerMsg" style="flex:1;color:#fbbf24;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"></span>` +
    `<button id="kbTimerClose" title="이 탭에서 숨기기" style="all:initial;color:#94a3b8;cursor:pointer;font:16px sans-serif;padding:0 4px">✕</button>`;
  (document.body || document.documentElement).appendChild(bar);

  const $ = (id) => bar.querySelector('#' + id);
  const elLabel = $('kbTimerLabel'), elTime = $('kbTimerTime'),
    elCount = $('kbTimerCount'), elStatus = $('kbTimerStatus'), elMsg = $('kbTimerMsg');

  // ── 발주 시각 계산: HH:MM → 오늘(지났으면 내일) ms ──
  function timeToDeadline(hhmm) {
    if (!hhmm) return 0;
    const [h, m] = hhmm.split(':').map(Number);
    if (isNaN(h)) return 0;
    const d = new Date(); d.setHours(h, m, 0, 0);
    let ms = d.getTime();
    if (ms < Date.now() - 60000) ms += 24 * 3600 * 1000;
    return ms;
  }

  // ── 소리 (포커스된 탭에서만) ──
  function beep() {
    if (!document.hasFocus()) return;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      const ctx = new AC();
      [0, 0.6, 1.2].forEach((t) => {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.connect(g); g.connect(ctx.destination);
        o.type = 'sine'; o.frequency.value = 880;
        g.gain.setValueAtTime(0.0001, ctx.currentTime + t);
        g.gain.exponentialRampToValueAtTime(0.3, ctx.currentTime + t + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + t + 0.45);
        o.start(ctx.currentTime + t); o.stop(ctx.currentTime + t + 0.5);
      });
    } catch (_) { /* 무시 */ }
  }

  // ── 발주 시각 변경 시: 이미 지난 단계는 조용히 fired 처리 ──
  function resetFired() {
    fired = new Set();
    if (!deadline) return;
    const left = deadline - Date.now();
    STAGES.forEach((s) => { if (left <= s.min * 60000) fired.add(s.min); });
  }

  // ── 1초 틱: 카운트다운 + 상태 + 단계 알림 ──
  function tick() {
    if (!deadline) {
      elCount.textContent = '--:--';
      elStatus.textContent = '대기'; elStatus.style.background = '#334155';
      return;
    }
    const left = deadline - Date.now();
    if (left <= 0) {
      elCount.textContent = '00:00';
      elStatus.textContent = '🔴 마감'; elStatus.style.background = '#7f1d1d';
      elCount.style.color = '#f87171';
      return;
    }
    const sec = Math.floor(left / 1000);
    const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    elCount.textContent = (h > 0 ? `${h}:${String(m).padStart(2, '0')}` : String(m)) + ':' + String(s).padStart(2, '0');
    elCount.style.color = left <= 60000 ? '#f87171' : left <= 300000 ? '#fbbf24' : '#e2e8f0';
    elStatus.textContent = '🟢 베팅가능'; elStatus.style.background = '#14532d';

    // 단계 알림 (임계 진입 시 1회)
    for (const st of STAGES) {
      if (left <= st.min * 60000 && !fired.has(st.min)) {
        fired.add(st.min);
        elMsg.textContent = `🔔 ${st.min}분 전 · ${st.msg}`;
        msgUntil = Date.now() + 20000;
        beep();
      }
    }
    if (msgUntil && Date.now() > msgUntil) { elMsg.textContent = ''; msgUntil = 0; }
  }

  // ── 입력 → storage 저장 (모든 탭 공유) ──
  elTime.addEventListener('change', () => {
    chrome.storage.local.set({ timerTime: elTime.value, timerDeadline: timeToDeadline(elTime.value) });
  });
  elLabel.addEventListener('change', () => chrome.storage.local.set({ timerLabel: elLabel.value }));
  $('kbTimerClose').addEventListener('click', () => bar.remove());

  // ── storage 변경 → 모든 탭 동기화 ──
  function applyState(v) {
    if (v.timerLabel != null && document.activeElement !== elLabel) elLabel.value = v.timerLabel || '';
    if (v.timerTime != null && document.activeElement !== elTime) elTime.value = v.timerTime || '';
    const nd = v.timerDeadline || 0;
    if (nd !== deadline) { deadline = nd; resetFired(); }
    if (elLabel.value) elLabel.title = elLabel.value;
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.timerDeadline || changes.timerLabel || changes.timerTime) {
      chrome.storage.local.get({ timerDeadline: 0, timerLabel: '', timerTime: '' }, applyState);
    }
  });

  // ── 초기화 ──
  chrome.storage.local.get({ timerDeadline: 0, timerLabel: '', timerTime: '' }, (v) => {
    applyState(v); tick();
  });
  setInterval(tick, 1000);
})();
